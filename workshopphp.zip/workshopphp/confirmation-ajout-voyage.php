<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Confirmation d'Ajout de Voyage</title>
</head>

<body>
    <header>
        <h1>Confirmation d'Ajout de Voyage</h1>
    </header>
    <section id="confirmation-message">
        <p>Le voyage a été ajouté avec succès.</p>
        <a href="index.php">Retour à la page d'accueil</a>
    </section>
</body>

</html>