<footer>

    <p>Contactez-nous : contact@monsitevoyages.com</p>
    <p>Suivez-nous sur <a href="www.facebook.com">Facebook</a> et <a href="www.instagram.com">Instagram</a></p>

</footer>