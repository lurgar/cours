PHP
- Variables ($)
- Fonction ( avec ou sans paramêtres)
- Boucles
- Conditions
- Tableaux

- <?php  ?>

- instructions
    - random_int() (0 - x)
    - echo ( qui affiche au sein de l'html )
    - var_dump() & print_r() ( qui affiche le contenu d'un tableau )
    - substr( qui renvoie un segment de chaîne )

Exo
- création d'une fonction
- des conditions 
- créer des tableaux + les parcouris avec for() & foreach()



- Formulaire - méthode POST : print_r, echo + clé
- Création de fichier - file get content
    - Création de log dev
    - récupération d'info via log + dynamisation
    - création de tableau php alimenté en contenue + JSON et dynamisation


 

