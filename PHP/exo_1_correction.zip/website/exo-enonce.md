Exo : 


    Créer un nouveau formulaire : Personnalisation

        - Input -> Ajouter la couleur
    
    Enregistrez la couleur dans un fichier .txt

    Puis, récuperer l'information du fichier .txt pour changer la couleur du header du site


Exo2 :

    Via le formulaire de personalisation (couleur)
    Ajouter un champ pour :
        - Titre du site ( text )
        - Titre du header ( text )
        - Sous-Titre du header ( text )
        - Image du produit ( ??? )

    Ajouter les infos à travers un tablau de donnée en JSON
    pour les exploiter plus tard 


        // créer un tableau
        // transférer les données de $_POST => nouveau tableau
        // convertir le nouveau tableau PHP en JSON
        // Créer un fichier JSON et y inclure le tableau JSON